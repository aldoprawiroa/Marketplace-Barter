
const dummyData = [
  { id: "B01", nama: "Kamera Sony A6000", harga: 3200000, kategori: "Elektronik" },
  { id: "B02", nama: "Sepeda Lipat Brompton", harga: 4500000, kategori: "Olahraga" },
  { id: "B03", nama: "Jaket Kulit Asli", harga: 800000, kategori: "Fashion" },
  { id: "B04", nama: "MacBook Air M1", harga: 11000000, kategori: "Elektronik" },
  { id: "B05", nama: "Sepatu Compass", harga: 650000, kategori: "Fashion" }
];
